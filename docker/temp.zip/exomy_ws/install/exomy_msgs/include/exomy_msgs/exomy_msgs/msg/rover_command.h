// generated from rosidl_generator_c/resource/idl.h.em
// with input from exomy_msgs:msg/RoverCommand.idl
// generated code does not contain a copyright notice

#ifndef EXOMY_MSGS__MSG__ROVER_COMMAND_H_
#define EXOMY_MSGS__MSG__ROVER_COMMAND_H_

#include "exomy_msgs/msg/detail/rover_command__struct.h"
#include "exomy_msgs/msg/detail/rover_command__functions.h"
#include "exomy_msgs/msg/detail/rover_command__type_support.h"

#endif  // EXOMY_MSGS__MSG__ROVER_COMMAND_H_

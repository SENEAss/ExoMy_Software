// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from exomy_msgs:msg/RoverCommand.idl
// generated code does not contain a copyright notice

#ifndef EXOMY_MSGS__MSG__DETAIL__ROVER_COMMAND__TRAITS_HPP_
#define EXOMY_MSGS__MSG__DETAIL__ROVER_COMMAND__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "exomy_msgs/msg/detail/rover_command__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace exomy_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const RoverCommand & msg,
  std::ostream & out)
{
  out << "{";
  // member: connected
  {
    out << "connected: ";
    rosidl_generator_traits::value_to_yaml(msg.connected, out);
    out << ", ";
  }

  // member: motors_enabled
  {
    out << "motors_enabled: ";
    rosidl_generator_traits::value_to_yaml(msg.motors_enabled, out);
    out << ", ";
  }

  // member: locomotion_mode
  {
    out << "locomotion_mode: ";
    rosidl_generator_traits::value_to_yaml(msg.locomotion_mode, out);
    out << ", ";
  }

  // member: vel
  {
    out << "vel: ";
    rosidl_generator_traits::value_to_yaml(msg.vel, out);
    out << ", ";
  }

  // member: steering
  {
    out << "steering: ";
    rosidl_generator_traits::value_to_yaml(msg.steering, out);
    out << ", ";
  }

  // member: force_stop
  {
    out << "force_stop: ";
    rosidl_generator_traits::value_to_yaml(msg.force_stop, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const RoverCommand & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: connected
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "connected: ";
    rosidl_generator_traits::value_to_yaml(msg.connected, out);
    out << "\n";
  }

  // member: motors_enabled
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "motors_enabled: ";
    rosidl_generator_traits::value_to_yaml(msg.motors_enabled, out);
    out << "\n";
  }

  // member: locomotion_mode
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "locomotion_mode: ";
    rosidl_generator_traits::value_to_yaml(msg.locomotion_mode, out);
    out << "\n";
  }

  // member: vel
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "vel: ";
    rosidl_generator_traits::value_to_yaml(msg.vel, out);
    out << "\n";
  }

  // member: steering
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "steering: ";
    rosidl_generator_traits::value_to_yaml(msg.steering, out);
    out << "\n";
  }

  // member: force_stop
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "force_stop: ";
    rosidl_generator_traits::value_to_yaml(msg.force_stop, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const RoverCommand & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace exomy_msgs

namespace rosidl_generator_traits
{

[[deprecated("use exomy_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const exomy_msgs::msg::RoverCommand & msg,
  std::ostream & out, size_t indentation = 0)
{
  exomy_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use exomy_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const exomy_msgs::msg::RoverCommand & msg)
{
  return exomy_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<exomy_msgs::msg::RoverCommand>()
{
  return "exomy_msgs::msg::RoverCommand";
}

template<>
inline const char * name<exomy_msgs::msg::RoverCommand>()
{
  return "exomy_msgs/msg/RoverCommand";
}

template<>
struct has_fixed_size<exomy_msgs::msg::RoverCommand>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<exomy_msgs::msg::RoverCommand>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<exomy_msgs::msg::RoverCommand>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // EXOMY_MSGS__MSG__DETAIL__ROVER_COMMAND__TRAITS_HPP_

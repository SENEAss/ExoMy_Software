// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from exomy_msgs:msg/MotorCommands.idl
// generated code does not contain a copyright notice

#ifndef EXOMY_MSGS__MSG__DETAIL__MOTOR_COMMANDS__TRAITS_HPP_
#define EXOMY_MSGS__MSG__DETAIL__MOTOR_COMMANDS__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "exomy_msgs/msg/detail/motor_commands__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace exomy_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const MotorCommands & msg,
  std::ostream & out)
{
  out << "{";
  // member: motor_speeds
  {
    if (msg.motor_speeds.size() == 0) {
      out << "motor_speeds: []";
    } else {
      out << "motor_speeds: [";
      size_t pending_items = msg.motor_speeds.size();
      for (auto item : msg.motor_speeds) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: motor_angles
  {
    if (msg.motor_angles.size() == 0) {
      out << "motor_angles: []";
    } else {
      out << "motor_angles: [";
      size_t pending_items = msg.motor_angles.size();
      for (auto item : msg.motor_angles) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const MotorCommands & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: motor_speeds
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.motor_speeds.size() == 0) {
      out << "motor_speeds: []\n";
    } else {
      out << "motor_speeds:\n";
      for (auto item : msg.motor_speeds) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: motor_angles
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.motor_angles.size() == 0) {
      out << "motor_angles: []\n";
    } else {
      out << "motor_angles:\n";
      for (auto item : msg.motor_angles) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const MotorCommands & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace exomy_msgs

namespace rosidl_generator_traits
{

[[deprecated("use exomy_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const exomy_msgs::msg::MotorCommands & msg,
  std::ostream & out, size_t indentation = 0)
{
  exomy_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use exomy_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const exomy_msgs::msg::MotorCommands & msg)
{
  return exomy_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<exomy_msgs::msg::MotorCommands>()
{
  return "exomy_msgs::msg::MotorCommands";
}

template<>
inline const char * name<exomy_msgs::msg::MotorCommands>()
{
  return "exomy_msgs/msg/MotorCommands";
}

template<>
struct has_fixed_size<exomy_msgs::msg::MotorCommands>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<exomy_msgs::msg::MotorCommands>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<exomy_msgs::msg::MotorCommands>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // EXOMY_MSGS__MSG__DETAIL__MOTOR_COMMANDS__TRAITS_HPP_
